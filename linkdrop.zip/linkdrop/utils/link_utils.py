"""
LinkDrop - Link Doğrulama ve Platform Algılama
Gelen mesajdan URL çıkarır, platformu tespit eder ve zararlı/geçersiz
bağlantıları eler.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

from models.models import Platform

# Yalnızca bilinen video platformlarının domainlerine izin ver (allow-list).
# Bu yaklaşım, zararlı/rastgele bağlantıların indirilmeye çalışılmasını engeller.
_ALLOWED_DOMAINS: dict[Platform, tuple[str, ...]] = {
    Platform.TIKTOK: ("tiktok.com", "vm.tiktok.com", "vt.tiktok.com"),
    Platform.INSTAGRAM: ("instagram.com", "instagr.am"),
    Platform.YOUTUBE: ("youtube.com", "youtu.be", "m.youtube.com"),
    Platform.FACEBOOK: ("facebook.com", "fb.watch", "m.facebook.com"),
    Platform.TWITTER: ("twitter.com", "x.com"),
}

_URL_PATTERN = re.compile(r"https?://[^\s]+", re.IGNORECASE)


def extract_url(text: str) -> str | None:
    """Serbest metin içinden ilk geçerli http(s) URL'sini çıkarır."""
    if not text:
        return None
    match = _URL_PATTERN.search(text.strip())
    return match.group(0) if match else None


def detect_platform(url: str) -> Platform:
    """Verilen URL'nin hangi platforma ait olduğunu domain'e bakarak tespit eder."""
    try:
        parsed = urlparse(url)
        hostname = (parsed.hostname or "").lower().removeprefix("www.")
    except ValueError:
        return Platform.UNKNOWN

    if not hostname or parsed.scheme not in ("http", "https"):
        return Platform.UNKNOWN

    for platform, domains in _ALLOWED_DOMAINS.items():
        if any(hostname == d or hostname.endswith("." + d) for d in domains):
            return platform
    return Platform.UNKNOWN


def is_supported_url(url: str) -> bool:
    """URL desteklenen bir platforma mı ait, kontrol eder (güvenlik allow-list)."""
    return detect_platform(url) != Platform.UNKNOWN


def sanitize_url(url: str) -> str:
    """URL'yi indirme öncesi temizler (izleme/tracking parametrelerini korur, boşlukları atar)."""
    return url.strip().strip("<>\"'")
