"""
LinkDrop - Çoklu Dil Desteği (i18n)
Azerbaycanca (az), Türkçe (tr) ve İngilizce (en) metinleri barındırır.
"""
from __future__ import annotations

SUPPORTED_LANGUAGES = ("az", "tr", "en")
DEFAULT_LANGUAGE = "az"

_TEXTS: dict[str, dict[str, str]] = {
    "welcome": {
        "az": (
            "👋 Salam, {name}!\n\n"
            "Mən <b>LinkDrop</b> botuyam. TikTok, Instagram, YouTube Shorts, "
            "Facebook və X (Twitter) linklərini mənə göndər, videonu sənin üçün endirim.\n\n"
            "Kömək üçün /help yaz."
        ),
        "tr": (
            "👋 Merhaba, {name}!\n\n"
            "Ben <b>LinkDrop</b> botuyum. TikTok, Instagram, YouTube Shorts, "
            "Facebook ve X (Twitter) linklerini bana gönder, videoyu senin için indireyim.\n\n"
            "Yardım için /help yaz."
        ),
        "en": (
            "👋 Hello, {name}!\n\n"
            "I'm <b>LinkDrop</b>. Send me a link from TikTok, Instagram, YouTube Shorts, "
            "Facebook or X (Twitter) and I'll download the video for you.\n\n"
            "Type /help for assistance."
        ),
    },
    "help": {
        "az": (
            "ℹ️ <b>Necə istifadə olunur?</b>\n\n"
            "1. Dəstəklənən platformalardan birindən video linkini kopyala.\n"
            "2. Linki mənə göndər.\n"
            "3. Mən videonu tapıb sənə göndərəcəm.\n\n"
            "Dəstəklənən platformalar: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)\n\n"
            "Dil dəyişmək üçün: /language"
        ),
        "tr": (
            "ℹ️ <b>Nasıl kullanılır?</b>\n\n"
            "1. Desteklenen platformlardan birinden video linkini kopyala.\n"
            "2. Linki bana gönder.\n"
            "3. Videoyu bulup sana göndereceğim.\n\n"
            "Desteklenen platformlar: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)\n\n"
            "Dil değiştirmek için: /language"
        ),
        "en": (
            "ℹ️ <b>How to use</b>\n\n"
            "1. Copy a video link from a supported platform.\n"
            "2. Send it to me.\n"
            "3. I'll fetch the video and send it back.\n\n"
            "Supported platforms: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)\n\n"
            "To change language: /language"
        ),
    },
    "choose_language": {
        "az": "🌐 Dilinizi seçin:",
        "tr": "🌐 Dilinizi seçin:",
        "en": "🌐 Choose your language:",
    },
    "language_set": {
        "az": "✅ Dil Azərbaycan dilinə dəyişdirildi.",
        "tr": "✅ Dil Türkçe olarak değiştirildi.",
        "en": "✅ Language set to English.",
    },
    "preparing": {
        "az": "⏳ Video hazırlanır, zəhmət olmasa gözləyin...",
        "tr": "⏳ Video hazırlanıyor, lütfen bekleyin...",
        "en": "⏳ Preparing your video, please wait...",
    },
    "invalid_link": {
        "az": (
            "❌ Bu link dəstəklənmir və ya düzgün deyil.\n"
            "Dəstəklənən platformalar: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)"
        ),
        "tr": (
            "❌ Bu link desteklenmiyor ya da geçersiz.\n"
            "Desteklenen platformlar: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)"
        ),
        "en": (
            "❌ This link isn't supported or is invalid.\n"
            "Supported platforms: TikTok, Instagram, YouTube Shorts, Facebook, X (Twitter)"
        ),
    },
    "no_url_found": {
        "az": "🔗 Zəhmət olmasa mənə bir video linki göndər.",
        "tr": "🔗 Lütfen bana bir video linki gönder.",
        "en": "🔗 Please send me a video link.",
    },
    "download_failed": {
        "az": "⚠️ Video endirilə bilmədi. Link məhdud, silinmiş və ya çox uzun ola bilər.",
        "tr": "⚠️ Video indirilemedi. Link kısıtlı, silinmiş veya çok uzun olabilir.",
        "en": "⚠️ Couldn't download the video. It may be private, deleted, or too long.",
    },
    "file_too_large": {
        "az": "⚠️ Video çox böyükdür (limit: {limit} MB).",
        "tr": "⚠️ Video çok büyük (limit: {limit} MB).",
        "en": "⚠️ The video is too large (limit: {limit} MB).",
    },
    "blocked": {
        "az": "🚫 Siz botdan istifadə etməkdən məhrum edilmisiniz.",
        "tr": "🚫 Bu bottan yararlanmanız engellendi.",
        "en": "🚫 You have been blocked from using this bot.",
    },
    "rate_limited": {
        "az": "⏱ Çox tez-tez sorğu göndərirsiniz. Bir az gözləyin.",
        "tr": "⏱ Çok hızlı istek gönderiyorsun. Biraz bekle.",
        "en": "⏱ You're sending requests too fast. Please slow down.",
    },
    "download_success_caption": {
        "az": "✅ Buyurun! 🎬 Platform: {platform}",
        "tr": "✅ Buyurun! 🎬 Platform: {platform}",
        "en": "✅ Here you go! 🎬 Platform: {platform}",
    },
    "admin_only": {
        "az": "⛔ Bu əmr yalnız adminlər üçündür.",
        "tr": "⛔ Bu komut yalnızca yöneticiler içindir.",
        "en": "⛔ This command is for admins only.",
    },
    "user_not_found": {
        "az": "❌ İstifadəçi tapılmadı.",
        "tr": "❌ Kullanıcı bulunamadı.",
        "en": "❌ User not found.",
    },
    "user_blocked_ok": {
        "az": "✅ İstifadəçi {user_id} bloklandı.",
        "tr": "✅ Kullanıcı {user_id} engellendi.",
        "en": "✅ User {user_id} has been blocked.",
    },
    "user_unblocked_ok": {
        "az": "✅ İstifadəçi {user_id} blokdan çıxarıldı.",
        "tr": "✅ Kullanıcı {user_id} engeli kaldırıldı.",
        "en": "✅ User {user_id} has been unblocked.",
    },
    "broadcast_usage": {
        "az": "İstifadə: /broadcast <mesaj>",
        "tr": "Kullanım: /broadcast <mesaj>",
        "en": "Usage: /broadcast <message>",
    },
    "broadcast_done": {
        "az": "📢 Yayım tamamlandı. Göndərildi: {sent}, Uğursuz: {failed}",
        "tr": "📢 Yayın tamamlandı. Gönderildi: {sent}, Başarısız: {failed}",
        "en": "📢 Broadcast complete. Sent: {sent}, Failed: {failed}",
    },
}


def t(key: str, lang: str = DEFAULT_LANGUAGE, **kwargs: object) -> str:
    """Verilen anahtar ve dil için metni döndürür; eksikse EN'e düşer."""
    lang = lang if lang in SUPPORTED_LANGUAGES else DEFAULT_LANGUAGE
    entry = _TEXTS.get(key)
    if entry is None:
        return key
    template = entry.get(lang) or entry.get("en") or key
    return template.format(**kwargs) if kwargs else template
