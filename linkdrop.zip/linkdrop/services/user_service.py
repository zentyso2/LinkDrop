"""
LinkDrop - Kullanıcı Servisi
Kullanıcı oluşturma, güncelleme, engelleme ve sorgulama işlemleri.
"""
from __future__ import annotations

import datetime as dt
import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from models.models import User

logger = logging.getLogger(__name__)


class UserService:
    """Kullanıcılarla ilgili tüm veritabanı işlemlerini kapsayan servis."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_or_create(
        self,
        user_id: int,
        username: str | None,
        first_name: str | None,
        language: str = "az",
    ) -> User:
        """Kullanıcı varsa döner, yoksa oluşturur; her çağrıda aktiflik zamanını günceller."""
        user = await self._session.get(User, user_id)
        if user is None:
            user = User(
                id=user_id,
                username=username,
                first_name=first_name,
                language=language,
            )
            self._session.add(user)
            logger.info("Yeni kullanıcı kaydedildi: %s", user_id)
        else:
            user.username = username
            user.first_name = first_name
            user.last_active_at = dt.datetime.now(dt.timezone.utc)
        await self._session.flush()
        return user

    async def get_by_id(self, user_id: int) -> User | None:
        return await self._session.get(User, user_id)

    async def set_language(self, user_id: int, language: str) -> None:
        user = await self._session.get(User, user_id)
        if user:
            user.language = language
            await self._session.flush()

    async def set_blocked(self, user_id: int, blocked: bool) -> bool:
        """Kullanıcıyı engeller/engelini kaldırır. Kullanıcı yoksa False döner."""
        user = await self._session.get(User, user_id)
        if user is None:
            return False
        user.is_blocked = blocked
        await self._session.flush()
        return True

    async def is_blocked(self, user_id: int) -> bool:
        user = await self._session.get(User, user_id)
        return bool(user and user.is_blocked)

    async def total_users(self) -> int:
        result = await self._session.execute(select(func.count()).select_from(User))
        return int(result.scalar_one())

    async def all_active_user_ids(self) -> list[int]:
        """Broadcast için engellenmemiş tüm kullanıcı ID'lerini döner."""
        result = await self._session.execute(
            select(User.id).where(User.is_blocked.is_(False))
        )
        return [row[0] for row in result.all()]
