"""
LinkDrop - İstatistik Servisi
Admin paneli ve raporlama için toplu sorgular.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from models.models import DownloadLog, DownloadStatus, Platform, User


class StatsService:
    """İndirme ve kullanıcı istatistiklerini hesaplayan servis."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def total_users(self) -> int:
        result = await self._session.execute(select(func.count()).select_from(User))
        return int(result.scalar_one())

    async def total_downloads(self) -> int:
        result = await self._session.execute(select(func.count()).select_from(DownloadLog))
        return int(result.scalar_one())

    async def downloads_today(self) -> int:
        start_of_day = dt.datetime.now(dt.timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        result = await self._session.execute(
            select(func.count())
            .select_from(DownloadLog)
            .where(DownloadLog.created_at >= start_of_day)
        )
        return int(result.scalar_one())

    async def downloads_by_platform(self) -> dict[str, int]:
        result = await self._session.execute(
            select(DownloadLog.platform, func.count())
            .group_by(DownloadLog.platform)
        )
        return {platform.value: count for platform, count in result.all()}

    async def success_rate(self) -> float:
        total = await self.total_downloads()
        if total == 0:
            return 0.0
        result = await self._session.execute(
            select(func.count())
            .select_from(DownloadLog)
            .where(DownloadLog.status == DownloadStatus.SUCCESS)
        )
        success = int(result.scalar_one())
        return round((success / total) * 100, 2)

    async def log_download(
        self,
        user_id: int,
        platform: Platform,
        url: str,
        status: DownloadStatus,
        error_message: str | None = None,
        file_size_bytes: int | None = None,
    ) -> None:
        entry = DownloadLog(
            user_id=user_id,
            platform=platform,
            url=url,
            status=status,
            error_message=error_message,
            file_size_bytes=file_size_bytes,
        )
        self._session.add(entry)
        await self._session.flush()
