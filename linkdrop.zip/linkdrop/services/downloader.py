"""
LinkDrop - Video İndirme Servisi
yt-dlp'yi thread pool üzerinden asenkron şekilde çalıştırır.
TikTok, Instagram, YouTube Shorts, Facebook ve X (Twitter) desteklenir.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass
from pathlib import Path

import yt_dlp

from config.settings import settings

logger = logging.getLogger(__name__)


class DownloadError(Exception):
    """İndirme işlemi sırasında oluşan beklenen hataları temsil eder."""


class FileTooLargeError(DownloadError):
    """İndirilen dosya izin verilen boyutu aştığında fırlatılır."""


@dataclass(slots=True)
class DownloadResult:
    """Başarılı bir indirme işleminin sonucu."""
    file_path: Path
    title: str
    file_size_bytes: int
    duration_seconds: float | None


class VideoDownloader:
    """yt-dlp'yi sarmalayan, eşzamanlılığı sınırlayan async indirme servisi."""

    def __init__(self) -> None:
        self._semaphore = asyncio.Semaphore(settings.max_concurrent_downloads)

    async def download(self, url: str) -> DownloadResult:
        """Verilen URL'den videoyu indirir ve sonucu döner. Hata durumunda DownloadError fırlatır."""
        async with self._semaphore:
            try:
                return await asyncio.wait_for(
                    asyncio.to_thread(self._download_sync, url),
                    timeout=settings.download_timeout_seconds,
                )
            except asyncio.TimeoutError as exc:
                raise DownloadError("İndirme zaman aşımına uğradı.") from exc

    def _download_sync(self, url: str) -> DownloadResult:
        """Blocking yt-dlp çağrısını ayrı thread'de çalıştırmak için senkron metod."""
        unique_id = uuid.uuid4().hex[:10]
        output_template = str(settings.downloads_dir / f"{unique_id}_%(id)s.%(ext)s")
        max_bytes = settings.max_file_size_mb * 1024 * 1024

        ydl_opts = {
            "outtmpl": output_template,
            "format": "best[ext=mp4]/best",
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "max_filesize": max_bytes,
            "retries": 2,
            "socket_timeout": settings.download_timeout_seconds,
            "merge_output_format": "mp4",
            "restrictfilenames": True,
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                if info is None:
                    raise DownloadError("Video bilgisi alınamadı.")
                file_path = Path(ydl.prepare_filename(info))
        except yt_dlp.utils.DownloadError as exc:
            message = str(exc)
            logger.warning("yt-dlp indirme hatası: %s | url=%s", message, url)
            if "max-filesize" in message.lower() or "too large" in message.lower():
                raise FileTooLargeError(message) from exc
            raise DownloadError(message) from exc
        except Exception as exc:  # noqa: BLE001 - beklenmeyen hataları da yönetilebilir hale getir
            logger.exception("Beklenmeyen indirme hatası: url=%s", url)
            raise DownloadError(str(exc)) from exc

        if not file_path.exists():
            raise DownloadError("İndirilen dosya bulunamadı.")

        file_size = file_path.stat().st_size
        if file_size > max_bytes:
            file_path.unlink(missing_ok=True)
            raise FileTooLargeError(f"Dosya boyutu limiti aşıyor: {file_size} bytes")

        return DownloadResult(
            file_path=file_path,
            title=info.get("title") or "video",
            file_size_bytes=file_size,
            duration_seconds=info.get("duration"),
        )

    @staticmethod
    def cleanup(file_path: Path) -> None:
        """Telegram'a gönderildikten sonra geçici dosyayı siler."""
        try:
            file_path.unlink(missing_ok=True)
        except OSError:
            logger.warning("Geçici dosya silinemedi: %s", file_path)


downloader = VideoDownloader()
