"""
LinkDrop - Klavye (Keyboard) Tanımları
"""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def language_keyboard() -> InlineKeyboardMarkup:
    """Dil seçim menüsü için inline klavye."""
    buttons = [
        [
            InlineKeyboardButton(text="🇦🇿 Azərbaycanca", callback_data="lang:az"),
            InlineKeyboardButton(text="🇹🇷 Türkçe", callback_data="lang:tr"),
        ],
        [
            InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:en"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)
