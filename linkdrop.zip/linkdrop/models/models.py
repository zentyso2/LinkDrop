"""
LinkDrop - Veritabanı Modelleri
SQLAlchemy 2.x ORM tabanlı, async uyumlu model tanımları.
"""
from __future__ import annotations

import datetime as dt
import enum

from sqlalchemy import BigInteger, Boolean, DateTime, Enum, ForeignKey, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Tüm modeller için temel sınıf."""
    pass


class Platform(str, enum.Enum):
    """Desteklenen video platformları."""
    TIKTOK = "tiktok"
    INSTAGRAM = "instagram"
    YOUTUBE = "youtube"
    FACEBOOK = "facebook"
    TWITTER = "twitter"
    UNKNOWN = "unknown"


class DownloadStatus(str, enum.Enum):
    """Bir indirme işleminin son durumu."""
    SUCCESS = "success"
    FAILED = "failed"
    REJECTED = "rejected"


class User(Base):
    """Botu kullanan her Telegram kullanıcısı için bir kayıt."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    language: Mapped[str] = mapped_column(String(2), default="az", nullable=False)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    joined_at: Mapped[dt.datetime] = mapped_column(
        DateTime, default=lambda: dt.datetime.now(dt.timezone.utc), nullable=False
    )
    last_active_at: Mapped[dt.datetime] = mapped_column(
        DateTime, default=lambda: dt.datetime.now(dt.timezone.utc), nullable=False
    )

    downloads: Mapped[list["DownloadLog"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username!r} blocked={self.is_blocked}>"


class DownloadLog(Base):
    """Her indirme denemesinin kaydı (istatistik ve denetim için)."""

    __tablename__ = "download_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    platform: Mapped[Platform] = mapped_column(Enum(Platform), nullable=False)
    url: Mapped[str] = mapped_column(String(1024), nullable=False)
    status: Mapped[DownloadStatus] = mapped_column(Enum(DownloadStatus), nullable=False)
    error_message: Mapped[str | None] = mapped_column(String(512), nullable=True)
    file_size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration_seconds: Mapped[float | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime, default=lambda: dt.datetime.now(dt.timezone.utc), nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="downloads")

    def __repr__(self) -> str:
        return f"<DownloadLog id={self.id} platform={self.platform} status={self.status}>"
