"""
LinkDrop - FastAPI İstatistik API'si
Bot ile aynı veritabanını okuyarak JSON istatistik uç noktaları sunar.
İleride web sitesi/mobil uygulama bu API üzerinden veri çekebilir.
Sadece API_ENABLED=true olduğunda main.py tarafından başlatılır.
"""
from __future__ import annotations

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from database.db import get_session
from services.stats_service import StatsService

app = FastAPI(
    title="LinkDrop API",
    description="LinkDrop botunun istatistiklerine erişim sağlayan salt-okunur API.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/health", tags=["system"])
async def health_check() -> dict[str, str]:
    """Servisin ayakta olduğunu doğrulamak için basit sağlık kontrolü."""
    return {"status": "ok"}


@app.get("/stats/overview", tags=["stats"])
async def stats_overview() -> dict[str, object]:
    """Genel bot istatistiklerinin özetini döner."""
    async with get_session() as session:
        service = StatsService(session)
        return {
            "total_users": await service.total_users(),
            "total_downloads": await service.total_downloads(),
            "downloads_today": await service.downloads_today(),
            "success_rate": await service.success_rate(),
            "downloads_by_platform": await service.downloads_by_platform(),
        }


@app.get("/stats/platforms", tags=["stats"])
async def stats_platforms() -> dict[str, int]:
    """Platform bazlı indirme sayılarını döner."""
    async with get_session() as session:
        return await StatsService(session).downloads_by_platform()


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request, exc: Exception):  # noqa: ANN001
    """Beklenmeyen hataları güvenli, bilgi sızdırmayan bir formatta döner."""
    raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error") from exc
