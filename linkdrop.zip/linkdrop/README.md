# LinkDrop 📥

TikTok, Instagram Reels, YouTube Shorts, Facebook və X (Twitter) linklərindən
video endirməyə yarayan, üretimə hazır Telegram botu.

## Xüsusiyyətlər

- 🌐 Çoxdilli dəstək: Azərbaycanca, Türkçe, English
- 🔍 Avtomatik platform algılama və link doğrulama (allow-list əsaslı)
- ⚡ Tam asenkron mimari (aiogram 3.x + asyncio)
- 🛡 Flood/spam qoruması, rate limit
- 🗄 SQLAlchemy + SQLite (PostgreSQL-ə keçid dəstəklənir)
- 📊 Admin panel komandaları: `/stats`, `/broadcast`, `/block`, `/unblock`
- 🐳 Docker və Docker Compose ilə tək əmrlə deploy
- 🔌 Gələcək veb sayt/mobil tətbiq üçün FastAPI statistika API-si (opsional)

## Tələblər

- Python 3.12+
- ffmpeg (Docker image-də daxildir; lokal işlətsən ayrıca qur)
- Telegram Bot Token (@BotFather)

## Qurulum (lokal)

```bash
# 1. Asılılıqları quraşdır
pip install -r requirements.txt

# 2. .env faylını yarat
cp .env.example .env
# .env faylını aç və BOT_TOKEN, ADMIN_IDS dəyərlərini doldur

# 3. Botu başlat
python main.py
```

## .env Ayarları

| Dəyişən | Təsvir | Default |
|---|---|---|
| `BOT_TOKEN` | @BotFather-dan alınan token | — (məcburi) |
| `ADMIN_IDS` | Admin Telegram ID-ləri, vergüllə | boş |
| `DATABASE_URL` | Verilənlər bazası bağlantı sətri | `sqlite+aiosqlite:///./linkdrop.db` |
| `DOWNLOADS_DIR` | Müvəqqəti video qovluğu | `./downloads` |
| `MAX_FILE_SIZE_MB` | Maksimum video ölçüsü (MB) | `50` |
| `DOWNLOAD_TIMEOUT_SECONDS` | Endirmə timeout-u | `120` |
| `MAX_CONCURRENT_DOWNLOADS` | Eyni anda maksimum endirmə sayı | `10` |
| `RATE_LIMIT_SECONDS` | Ardıcıl sorğular arası minimum fasilə | `3.0` |
| `MAX_REQUESTS_PER_MINUTE` | İstifadəçi başına dəqiqəlik limit | `15` |
| `LOG_LEVEL` | Log səviyyəsi | `INFO` |
| `DEFAULT_LANGUAGE` | Default dil (az/tr/en) | `az` |
| `API_ENABLED` | FastAPI statistika API-sini aktiv et | `false` |

## Docker ilə Qurulum

```bash
# .env faylını hazırla (yuxarıdakı kimi)
cp .env.example .env

# Build və başlat
docker compose up -d --build

# Logları izlə
docker compose logs -f linkdrop-bot

# Dayandır
docker compose down
```

## Admin Komandaları

| Komanda | Təsvir |
|---|---|
| `/stats` | Ümumi istifadəçi/endirmə statistikası |
| `/broadcast <mesaj>` | Bütün aktiv istifadəçilərə mesaj göndər |
| `/block <user_id>` | İstifadəçini blokla |
| `/unblock <user_id>` | Bloku qaldır |

Bu komandalar yalnız `.env` faylındakı `ADMIN_IDS` siyahısında olan
istifadəçilər tərəfindən istifadə oluna bilər.

## Layihə Strukturu

```
linkdrop/
├── app/            # FastAPI tətbiqi (opsional statistika API-si)
├── config/         # Konfiqurasiya və logging
├── database/       # DB engine/session idarəetməsi
├── handlers/       # Telegram mesaj/komanda handler-ləri
├── keyboards/       # Inline klaviaturalar
├── middlewares/     # Throttling və user-context middleware-ləri
├── models/          # SQLAlchemy modelləri
├── services/         # Biznes məntiqi (downloader, user, stats)
├── utils/           # Link doğrulama, i18n
├── downloads/        # Müvəqqəti video faylları (runtime)
├── logs/             # Log faylları (runtime)
├── main.py
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

## Sorun Giderme

**Bot cavab vermir**
- `BOT_TOKEN` düzgündürmü yoxla, `@BotFather`-dan `/mybots` ilə təsdiqlə.
- `docker compose logs -f linkdrop-bot` ilə xəta loqlarına bax.

**Video endirilmir / "download_failed"**
- Platform öz tərəfindən içeriyi məhdudlaşdırmış (private/geo-block) ola bilər.
- `yt-dlp` versiyası köhnəlmiş ola bilər — `pip install -U yt-dlp` ilə yenilə
  (platformlar tez-tez öz strukturlarını dəyişdirir).

**"file_too_large" xətası**
- `.env` faylında `MAX_FILE_SIZE_MB` dəyərini artır (Telegram botları üçün
  standart limit 50MB-dır, yerli Bot API server istifadə etsən daha yüksək ola bilər).

**Verilənlər bazası kilidlənməsi (SQLite)**
- Yüksək trafikdə SQLite məhdudiyyətlərə çata bilər. Bu halda `DATABASE_URL`-i
  PostgreSQL-ə yönəlt (`postgresql+asyncpg://...`) — kod dəyişikliyi tələb etmir.

## Lisenziya

Bu layihə şəxsi/kommersiya istifadə üçün açıq buraxılmışdır. Üçüncü tərəf
platformların (TikTok, Instagram, YouTube, Facebook, X) istifadə şərtlərinə
uyğun istifadə etmək istifadəçinin öz məsuliyyətindədir.

## Töhfə Vermə Bələdçisi

1. Repo-nu fork et
2. Yeni branch aç: `git checkout -b feature/yeni-xususiyyet`
3. Dəyişiklikləri commit et: `git commit -m "feat: yeni xususiyyet"`
4. Branch-i push et: `git push origin feature/yeni-xususiyyet`
5. Pull Request aç

Kod standartlarına (PEP8, type hints, modüler struktur) uyğunluğu qoru.
