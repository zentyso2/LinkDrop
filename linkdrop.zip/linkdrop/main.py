"""
LinkDrop - Ana Giriş Noktası
Telegram botunu (aiogram, polling) ve isteğe bağlı FastAPI istatistik API'sini
aynı asyncio event loop içinde başlatır.
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config.logging_config import setup_logging
from config.settings import settings
from database.db import close_db, init_db
from handlers import admin_handlers, user_handlers
from middlewares.throttling import ThrottlingMiddleware
from middlewares.user_context import UserContextMiddleware

logger = logging.getLogger(__name__)


async def _run_api_server() -> None:
    """FastAPI uygulamasını uvicorn ile aynı event loop içinde çalıştırır."""
    import uvicorn

    from app.api import app as fastapi_app

    config = uvicorn.Config(
        fastapi_app,
        host=settings.api_host,
        port=settings.api_port,
        log_level=settings.log_level.lower(),
    )
    server = uvicorn.Server(config)
    await server.serve()


async def _run_bot() -> None:
    """Telegram botunu polling modunda başlatır."""
    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dispatcher = Dispatcher()

    # Middleware'ler: önce throttling (spam engelle), sonra kullanıcı bağlamı (DB kaydı)
    dispatcher.message.middleware(ThrottlingMiddleware())
    dispatcher.message.middleware(UserContextMiddleware())
    dispatcher.callback_query.middleware(UserContextMiddleware())

    # Handler router'ları: admin önce (daha spesifik filtreler), sonra genel kullanıcı handler'ları
    dispatcher.include_router(admin_handlers.router)
    dispatcher.include_router(user_handlers.router)

    logger.info("LinkDrop botu başlatılıyor...")
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dispatcher.start_polling(bot)
    finally:
        await bot.session.close()


async def main() -> None:
    """Uygulamanın ana orkestrasyon fonksiyonu."""
    setup_logging()
    logger.info("LinkDrop başlatılıyor | log_level=%s", settings.log_level)

    await init_db()

    tasks = [asyncio.create_task(_run_bot())]
    if settings.api_enabled:
        logger.info("FastAPI istatistik API'si aktif | port=%s", settings.api_port)
        tasks.append(asyncio.create_task(_run_api_server()))

    try:
        await asyncio.gather(*tasks)
    finally:
        await close_db()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("LinkDrop kapatılıyor (KeyboardInterrupt).")
