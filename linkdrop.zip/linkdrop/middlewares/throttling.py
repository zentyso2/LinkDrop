"""
LinkDrop - Flood/Rate-Limit Koruma Middleware'i
Kullanıcı bazlı hem "ardışık istek aralığı" hem de "dakikalık istek sayısı"
sınırlaması uygular. Bellek içi (in-memory) çalışır; tek instance için yeterlidir.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from config.settings import settings
from utils.i18n import t


class ThrottlingMiddleware(BaseMiddleware):
    """Kullanıcı başına flood/spam koruması sağlayan middleware."""

    def __init__(self) -> None:
        super().__init__()
        self._last_request: Dict[int, float] = {}
        self._request_windows: Dict[int, deque[float]] = defaultdict(deque)

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)

        now = time.monotonic()
        user_id = user.id

        # 1) Ardışık istekler arası minimum bekleme süresi
        last_time = self._last_request.get(user_id, 0.0)
        if now - last_time < settings.rate_limit_seconds:
            if hasattr(event, "answer"):
                lang = data.get("user_language", settings.default_language)
                await event.answer(t("rate_limited", lang))  # type: ignore[attr-defined]
            return None
        self._last_request[user_id] = now

        # 2) Dakikalık toplam istek limiti (sliding window)
        window = self._request_windows[user_id]
        window.append(now)
        while window and now - window[0] > 60:
            window.popleft()
        if len(window) > settings.max_requests_per_minute:
            if hasattr(event, "answer"):
                lang = data.get("user_language", settings.default_language)
                await event.answer(t("rate_limited", lang))  # type: ignore[attr-defined]
            return None

        return await handler(event, data)
