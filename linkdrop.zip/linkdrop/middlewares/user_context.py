"""
LinkDrop - Kullanıcı Bağlamı Middleware'i
Her gelen güncellemede: kullanıcıyı DB'de oluşturur/günceller, engel durumunu
kontrol eder ve dil bilgisini handler'lara aktarır.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from config.settings import settings
from database.db import get_session
from services.user_service import UserService
from utils.i18n import t

logger = logging.getLogger(__name__)


class UserContextMiddleware(BaseMiddleware):
    """Kullanıcıyı veritabanına kaydeder/günceller ve engel kontrolü yapar."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None or user.is_bot:
            return await handler(event, data)

        async with get_session() as session:
            service = UserService(session)
            db_user = await service.get_or_create(
                user_id=user.id,
                username=user.username,
                first_name=user.first_name,
                language=settings.default_language,
            )

            if db_user.is_blocked:
                if hasattr(event, "answer"):
                    await event.answer(t("blocked", db_user.language))  # type: ignore[attr-defined]
                logger.info("Engellenmiş kullanıcıdan istek reddedildi: %s", user.id)
                return None

            data["user_language"] = db_user.language
            data["db_user_id"] = db_user.id

        return await handler(event, data)
