"""
LinkDrop - Veritabanı Bağlantı Yönetimi
Async SQLAlchemy engine ve session factory burada tanımlanır.
SQLite ile başlar, DATABASE_URL değiştirilerek PostgreSQL'e geçilebilir.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from config.settings import settings
from models.models import Base

logger = logging.getLogger(__name__)

engine = create_async_engine(
    settings.database_url,
    echo=False,
    future=True,
)

async_session_factory = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


async def init_db() -> None:
    """Uygulama başlarken tabloları oluşturur (yoksa)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Veritabanı tabloları hazır.")


@asynccontextmanager
async def get_session() -> AsyncIterator[AsyncSession]:
    """Tek bir iş birimi (unit of work) için async session sağlar."""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def close_db() -> None:
    """Uygulama kapanırken engine'i düzgünce serbest bırakır."""
    await engine.dispose()
    logger.info("Veritabanı bağlantısı kapatıldı.")
