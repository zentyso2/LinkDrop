"""
LinkDrop - Merkezi Konfigürasyon Modülü
Tüm ortam değişkenleri (.env) buradan okunur ve doğrulanır.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """Uygulama genelinde kullanılan tüm ayarlar."""

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- Telegram ---
    bot_token: str = Field(..., alias="BOT_TOKEN")
    admin_ids_raw: str = Field(default="", alias="ADMIN_IDS")

    # --- Veritabanı ---
    database_url: str = Field(default="sqlite+aiosqlite:///./linkdrop.db", alias="DATABASE_URL")

    # --- İndirme ayarları ---
    downloads_dir: Path = Field(default=BASE_DIR / "downloads", alias="DOWNLOADS_DIR")
    max_file_size_mb: int = Field(default=50, alias="MAX_FILE_SIZE_MB")
    download_timeout_seconds: int = Field(default=120, alias="DOWNLOAD_TIMEOUT_SECONDS")
    max_concurrent_downloads: int = Field(default=10, alias="MAX_CONCURRENT_DOWNLOADS")

    # --- Rate limit / flood koruması ---
    rate_limit_seconds: float = Field(default=3.0, alias="RATE_LIMIT_SECONDS")
    max_requests_per_minute: int = Field(default=15, alias="MAX_REQUESTS_PER_MINUTE")

    # --- Loglama ---
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    log_dir: Path = Field(default=BASE_DIR / "logs", alias="LOG_DIR")

    # --- Varsayılan dil ---
    default_language: str = Field(default="az", alias="DEFAULT_LANGUAGE")

    # --- FastAPI (opsiyonel istatistik API'si) ---
    api_host: str = Field(default="0.0.0.0", alias="API_HOST")
    api_port: int = Field(default=8000, alias="API_PORT")
    api_enabled: bool = Field(default=False, alias="API_ENABLED")

    @property
    def admin_ids(self) -> List[int]:
        """'123,456' formatındaki ADMIN_IDS string'ini int listesine çevirir."""
        if not self.admin_ids_raw:
            return []
        return [int(item.strip()) for item in self.admin_ids_raw.split(",") if item.strip()]

    def ensure_directories(self) -> None:
        """Uygulama için gerekli klasörlerin var olduğundan emin olur."""
        self.downloads_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_directories()
