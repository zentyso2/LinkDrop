"""
LinkDrop - Kullanıcı Handler'ları
/start, /help, /language komutları ve gelen video linklerinin işlenmesi.
"""
from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, FSInputFile, Message

from config.settings import settings
from database.db import get_session
from keyboards.keyboards import language_keyboard
from models.models import DownloadStatus
from services.downloader import DownloadError, FileTooLargeError, downloader
from services.stats_service import StatsService
from services.user_service import UserService
from utils.i18n import t
from utils.link_utils import detect_platform, extract_url, is_supported_url, sanitize_url

logger = logging.getLogger(__name__)
router = Router(name="user_handlers")


@router.message(CommandStart())
async def handle_start(message: Message, user_language: str) -> None:
    """‘/start’ komutu — hoş geldin mesajı gönderir."""
    name = message.from_user.first_name or "dostum"
    await message.answer(t("welcome", user_language, name=name))


@router.message(Command("help"))
async def handle_help(message: Message, user_language: str) -> None:
    """‘/help’ komutu — kullanım talimatlarını gönderir."""
    await message.answer(t("help", user_language))


@router.message(Command("language"))
async def handle_language(message: Message, user_language: str) -> None:
    """‘/language’ komutu — dil seçim menüsünü gösterir."""
    await message.answer(t("choose_language", user_language), reply_markup=language_keyboard())


@router.callback_query(F.data.startswith("lang:"))
async def handle_language_callback(callback: CallbackQuery) -> None:
    """Dil seçim butonlarına basıldığında kullanıcının dilini günceller."""
    if callback.data is None or callback.from_user is None:
        return
    lang_code = callback.data.split(":", maxsplit=1)[1]

    async with get_session() as session:
        service = UserService(session)
        await service.set_language(callback.from_user.id, lang_code)

    await callback.message.edit_text(t("language_set", lang_code))  # type: ignore[union-attr]
    await callback.answer()


@router.message(F.text)
async def handle_text_message(message: Message, user_language: str, db_user_id: int) -> None:
    """Serbest metin mesajlarını işler: URL arar, doğrular ve videoyu indirir."""
    raw_url = extract_url(message.text or "")

    if raw_url is None:
        await message.answer(t("no_url_found", user_language))
        return

    url = sanitize_url(raw_url)

    if not is_supported_url(url):
        await message.answer(t("invalid_link", user_language))
        return

    platform = detect_platform(url)
    status_message = await message.answer(t("preparing", user_language))

    try:
        result = await downloader.download(url)
    except FileTooLargeError:
        await status_message.edit_text(
            t("file_too_large", user_language, limit=settings.max_file_size_mb)
        )
        async with get_session() as session:
            await StatsService(session).log_download(
                user_id=db_user_id,
                platform=platform,
                url=url,
                status=DownloadStatus.REJECTED,
                error_message="file_too_large",
            )
        return
    except DownloadError as exc:
        logger.warning("İndirme başarısız: %s | url=%s", exc, url)
        await status_message.edit_text(t("download_failed", user_language))
        async with get_session() as session:
            await StatsService(session).log_download(
                user_id=db_user_id,
                platform=platform,
                url=url,
                status=DownloadStatus.FAILED,
                error_message=str(exc)[:500],
            )
        return

    try:
        video_file = FSInputFile(result.file_path)
        await message.answer_video(
            video=video_file,
            caption=t("download_success_caption", user_language, platform=platform.value),
        )
        await status_message.delete()

        async with get_session() as session:
            await StatsService(session).log_download(
                user_id=db_user_id,
                platform=platform,
                url=url,
                status=DownloadStatus.SUCCESS,
                file_size_bytes=result.file_size_bytes,
            )
    finally:
        downloader.cleanup(result.file_path)
