"""
LinkDrop - Admin Handler'ları
/stats, /broadcast, /block, /unblock komutları.
Sadece config.settings.admin_ids içindeki kullanıcı ID'leri erişebilir.
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import Message

from config.settings import settings
from database.db import get_session
from services.stats_service import StatsService
from services.user_service import UserService
from utils.i18n import t

logger = logging.getLogger(__name__)
router = Router(name="admin_handlers")


def _is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


@router.message(Command("stats"), F.from_user.func(lambda u: _is_admin(u.id)))
async def handle_stats(message: Message, user_language: str) -> None:
    """Genel bot istatistiklerini gösterir (sadece admin)."""
    async with get_session() as session:
        stats = StatsService(session)
        total_users = await stats.total_users()
        total_downloads = await stats.total_downloads()
        today = await stats.downloads_today()
        by_platform = await stats.downloads_by_platform()
        success_rate = await stats.success_rate()

    platform_lines = "\n".join(f"  • {name}: {count}" for name, count in by_platform.items()) or "  —"

    text = (
        "📊 <b>LinkDrop İstatistikləri</b>\n\n"
        f"👥 Toplam istifadəçi: <b>{total_users}</b>\n"
        f"⬇️ Toplam endirmə: <b>{total_downloads}</b>\n"
        f"📅 Bugünkü endirmə: <b>{today}</b>\n"
        f"✅ Uğur nisbəti: <b>{success_rate}%</b>\n\n"
        f"📱 Platform üzrə:\n{platform_lines}"
    )
    await message.answer(text)


@router.message(Command("block"), F.from_user.func(lambda u: _is_admin(u.id)))
async def handle_block(message: Message, user_language: str) -> None:
    """Bir kullanıcıyı engeller. Kullanım: /block <user_id>"""
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].lstrip("-").isdigit():
        await message.answer("İstifadə: /block <user_id>")
        return

    target_id = int(parts[1])
    async with get_session() as session:
        success = await UserService(session).set_blocked(target_id, True)

    if success:
        await message.answer(t("user_blocked_ok", user_language, user_id=target_id))
    else:
        await message.answer(t("user_not_found", user_language))


@router.message(Command("unblock"), F.from_user.func(lambda u: _is_admin(u.id)))
async def handle_unblock(message: Message, user_language: str) -> None:
    """Bir kullanıcının engelini kaldırır. Kullanım: /unblock <user_id>"""
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].lstrip("-").isdigit():
        await message.answer("İstifadə: /unblock <user_id>")
        return

    target_id = int(parts[1])
    async with get_session() as session:
        success = await UserService(session).set_blocked(target_id, False)

    if success:
        await message.answer(t("user_unblocked_ok", user_language, user_id=target_id))
    else:
        await message.answer(t("user_not_found", user_language))


@router.message(Command("broadcast"), F.from_user.func(lambda u: _is_admin(u.id)))
async def handle_broadcast(message: Message, bot: Bot, user_language: str) -> None:
    """Tüm aktif kullanıcılara mesaj yayınlar. Kullanım: /broadcast <mesaj>"""
    text = (message.text or "").partition(" ")[2].strip()
    if not text:
        await message.answer(t("broadcast_usage", user_language))
        return

    async with get_session() as session:
        user_ids = await UserService(session).all_active_user_ids()

    sent, failed = 0, 0
    for user_id in user_ids:
        try:
            await bot.send_message(chat_id=user_id, text=text)
            sent += 1
        except Exception:  # noqa: BLE001 - broadcast sırasında tekil hatalar akışı durdurmamalı
            failed += 1
        await asyncio.sleep(0.05)  # Telegram rate limit'e takılmamak için küçük gecikme

    await message.answer(t("broadcast_done", user_language, sent=sent, failed=failed))


@router.message(Command("stats", "block", "unblock", "broadcast"))
async def handle_admin_denied(message: Message, user_language: str) -> None:
    """Admin olmayan kullanıcılar admin komutlarını çağırırsa bu handler devreye girer."""
    await message.answer(t("admin_only", user_language))
